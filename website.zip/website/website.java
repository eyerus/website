
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import javax.swing.text.html.HTML;
import javax.xml.stream.events.EndDocument;
import java.util.Queue;

public class website {
    public static  void main(String [] args) {

        news();
    }


    public static void news() {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        WebDriver WDname = new ChromeDriver();

        WDname.get("https://addisfortune.net");
        WebElement name =  WDname.findElement(By.tagName("body"));
        String var =  name.getText();

        WDname.get("http://localhost:3000");

           WebElement name2 =  WDname.findElement(By.tagName("article"));
           name2.sendKeys(var);
        }

    }



