var express = require('express');
var fs = require('fs');
var app = express();

app.use(express.static('public'));



app.get('/', function(request, response){
	//response.send("just trying");


});

app.listen(3000);